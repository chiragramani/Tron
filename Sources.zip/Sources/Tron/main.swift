import Foundation

TronConfigInputCommand.main()
